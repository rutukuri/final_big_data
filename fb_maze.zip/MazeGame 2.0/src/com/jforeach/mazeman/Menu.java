package com.jforeach.mazeman;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;

import com.jforeach.mazeman.R.id;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Menu extends Activity implements OnClickListener {
	/** Called when the activity is first created. */
	Context context;
	Location location;
	double latitude;
	double longitude;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		context = this;
		ImageView imgMap = (ImageView) findViewById(R.id.bImage);
		TextView addressText = (TextView) findViewById(R.id.bText);

		LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		Criteria criteria = new Criteria();
		String provider = locationManager.getBestProvider(criteria, true);
		Location location = locationManager.getLastKnownLocation(provider);
		latitude = location.getLatitude();
		longitude = location.getLongitude();

		String url = "http://maps.googleapis.com/maps/api/staticmap?center="
				+ latitude + "," + longitude + "&zoom=15&markers=" + latitude
				+ "," + longitude + "&size=240x160&sensor=false";
		addressText.setText(getAddress());
		new DownloadImageTask(imgMap).execute(url);
		// Connection service call
		System.out.println("in menu only");
		Button bNewGame = (Button) findViewById(R.id.bNew);
		Button bAbout = (Button) findViewById(R.id.bAbout);
		Button bPrefs = (Button) findViewById(R.id.bPrefs);
		Button bExit = (Button) findViewById(R.id.bExit);
		Button bSMS = (Button) findViewById(R.id.bSms);
		Button bMap = (Button) findViewById(R.id.bMap);
		Button bPerformance = (Button) findViewById(R.id.bPerformance);
		Button bShare = (Button) findViewById(R.id.bShare);
		bNewGame.setOnClickListener(this);
		bAbout.setOnClickListener(this);
		bPrefs.setOnClickListener(this);
		bExit.setOnClickListener(this);
		bSMS.setOnClickListener(this);
		bPerformance.setOnClickListener(this);
		bMap.setOnClickListener(this);
		bShare.setOnClickListener(this);

		SharedPreferences prefs = PreferenceManager
				.getDefaultSharedPreferences(this);
		boolean skipSplash = prefs.getBoolean("skipSplash", false);
		startService(new Intent(this, ConnectionService.class));
		if (!skipSplash) {
			Intent splash = new Intent(Menu.this, Splash.class);
			startActivity(splash);
		}
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.bExit:
			Intent pie = new Intent(Menu.this, PieChart.class);
			startActivity(pie);
			break;
		case R.id.bNew:
			String[] levels = { "Maze 1", "Maze 2", "Maze 3" };
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle(getString(R.string.levelSelect));
			builder.setItems(levels, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int item) {
					Intent game = new Intent(Menu.this, Game.class);
					Maze maze = MazeCreator.getMaze(item + 1);
					game.putExtra("maze", maze);
					startActivity(game);
				}
			});
			AlertDialog alert = builder.create();
			alert.show();
			break;
		case R.id.bAbout:
			Intent about = new Intent(Menu.this, MainActivity.class);
			startActivity(about);
			break;
		case R.id.bPrefs:
			Intent prefs = new Intent(Menu.this, Timeline.class);
			startActivity(prefs);
			break;
		case R.id.bSms:
			Intent sendms = new Intent(Menu.this, SMS.class);
			startActivity(sendms);
			break;
		case R.id.bPerformance:
			Intent performanceT = new Intent(Menu.this, PerformanceMeter.class);
			startActivity(performanceT);
			break;

		case R.id.bMap:
			Intent mapA = new Intent(Menu.this, Map1.class);
			startActivity(mapA);
			break;

		case R.id.bShare:
			int x = 0,
			y = 0,
			z = 0,
			h = 0;
			x = TestGesture.leftge.size();
			y = TestGesture.rightge.size();
			z = TestGesture.topge.size();
			h = x + y + z;

			String mes = "I have completed Maze Man game in" + " " + h + " "
					+ "steps!";

			Intent share = new Intent(Intent.ACTION_SEND);
			share.setType("image/jpeg");
			String root = Environment.getExternalStorageDirectory().toString();

			File f = new File(root + "/Data/icon.png");

			Bitmap bmp = BitmapFactory.decodeFile(f.getAbsolutePath());

			share.putExtra(Intent.EXTRA_TEXT, mes);
			share.putExtra(Intent.EXTRA_SUBJECT, "My Maze Game Score");

			share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(f));
			startActivity(Intent.createChooser(share, "Share Image"));
		}
	}

	private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
		ImageView bmImage;

		public DownloadImageTask(ImageView bmImage) {
			this.bmImage = bmImage;
		}

		protected Bitmap doInBackground(String... urls) {
			String urldisplay = urls[0];
			Bitmap mIcon11 = null;
			try {
				InputStream in = new java.net.URL(urldisplay).openStream();
				mIcon11 = BitmapFactory.decodeStream(in);
			} catch (Exception e) {

				// Log.e("Error", e.getMessage());
				e.printStackTrace();
			}
			return mIcon11;
		}

		protected void onPostExecute(Bitmap result) {
			bmImage.setImageBitmap(result);
		}
	}

	private String getAddress() {

		String addressString = null;

		try {
			Geocoder geocoder = new Geocoder(context.getApplicationContext(),
					Locale.getDefault());
			List<Address> addresses = geocoder.getFromLocation(latitude,
					longitude, 1);
			StringBuilder sb = new StringBuilder();
			if (addresses.size() > 0) {
				Address address = addresses.get(0);
				for (int i = 0; i < address.getMaxAddressLineIndex(); i++)
					sb.append(address.getAddressLine(i)).append("\n");
			}

			addressString = sb.toString();
			System.out.println("Address from latlong: " + addressString);
			Log.e("Address from lat,long ;", addressString);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return addressString;
	}

}