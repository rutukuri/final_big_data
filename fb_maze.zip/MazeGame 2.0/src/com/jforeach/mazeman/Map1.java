package com.jforeach.mazeman;

import java.util.ArrayList;
import java.util.HashSet;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class Map1 extends FragmentActivity implements OnItemSelectedListener{
	GoogleMap Map;

	String[] childLocations;
	Spinner date_dd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		
		int x=0,y = 0, z = 0;
		final String what;
		LatLng pnts = null;
		
		double a[] = { 39.028808, 39.028824, 39.029024, 39.029066, 39.029058,
				39.029083, 39.029291, 39.029599, 39.029874, 39.030316 };
		double b[] = { -94.574571, -94.574861, -94.574850, -94.575065,
				-94.575569, -94.576031, -94.576020, -94.575998, -94.575998,
				-94.575955 };
		double c[] = { 39.037656, 39.037272, 39.036889, 39.036781, 39.036664,
				39.036689, 39.036681 };
		double d[] = { -94.585682, -94.585983, -94.586176, -94.586230,
				-94.586498, -94.586841, -94.586895 };
		double e[] = { 39.037646, 39.037346, 39.037062, 39.036846, 39.036596,
				39.036604, 39.036596, 39.036604 };
		double f[] = { -94.584829, -94.584851, -94.584883, -94.584883,
				-94.585205, -94.585473, -94.585473, -94.585967 };
		int i, j;
		super.onCreate(savedInstanceState);
		setContentView(R.layout.trackermap);

		date_dd = (Spinner) findViewById(R.id.spin);

		ArrayList<String> date_list = new ArrayList<String>();
		date_list.add("Select Date");
		date_list.add("07/29/2014");
		date_list.add("07/30/2014");
		date_list.add("Today's Stats");
		ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, date_list); //selected item will look like a spinner set from XML
		spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		date_dd.setAdapter(spinnerArrayAdapter);
		
		date_dd.setOnItemSelectedListener(new OnItemSelectedListener() {
		    @Override
		    public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
		    if(position==1)
		    {
		   
		    method1();
		    }
		    else if(position==2)
		    {
		    	method2();
		    }
		    else if(position==3)
		    {
		    	method3();
		    }
		    }

		    @Override
		    public void onNothingSelected(AdapterView<?> parentView) {
		        // your code here
		    }

		});
		
		
		if (x == 1) {
					} else if (x == 2) {
					} else if (x == 3) {
					}

		// LatLng pnts1 = new LatLng(39.028808, -94.574571);

		// LatLng pnts10 = new LatLng(39.030316, -94.575955);

	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub
		
	}
	public void method1()
	{
		int i=0;
		LatLng pnts = null;
		double a[] = { 39.028808, 39.028824, 39.029024, 39.029066, 39.029058,
				39.029083, 39.029291, 39.029599, 39.029874, 39.030316 };
		double b[] = { -94.574571, -94.574861, -94.574850, -94.575065,
				-94.575569, -94.576031, -94.576020, -94.575998, -94.575998,
				-94.575955 };
		
		LatLng pnts_first = new LatLng(a[0], b[0]);
		LatLng pnts_last = new LatLng(39.030316, -94.575955);
		PolylineOptions lineOptions = new PolylineOptions().width(15)
				.color(Color.BLUE).geodesic(true);

		for (i = 0; i < a.length; i++) {

			pnts = new LatLng(a[i], b[i]);
			lineOptions.add(pnts);

		}
		SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
				.findFragmentById(R.id.map);
		Map = mapFragment.getMap();

		Marker marker = Map.addMarker(new MarkerOptions()
				.position(pnts_first)
				.title("Initial")
				.icon(BitmapDescriptorFactory
						.fromResource(R.drawable.marker2)));

		Marker marker1 = Map.addMarker(new MarkerOptions()
				.position(pnts_last)
				.title("Final")
				.icon(BitmapDescriptorFactory
						.fromResource(R.drawable.marker3)));
		// lineOptions.add(pnts1);
		// lineOptions.add(pnts10);

		Map.addPolyline(lineOptions);
		CameraPosition cameraP = new CameraPosition.Builder().target(pnts)
				.zoom(16).bearing(90) // Sets the orientation of the camera
										// to
										// east
				.tilt(30) // Sets the tilt of the camera to 30 degrees
				.build();
		Map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraP));
		Map.setMapType(GoogleMap.MAP_TYPE_NORMAL);


	}
	
	public void method2()
	{int i=0;
	LatLng pnts = null;
		double c[] = { 39.037656, 39.037272, 39.036889, 39.036781, 39.036664,
				39.036689, 39.036681 };
		double d[] = { -94.585682, -94.585983, -94.586176, -94.586230,
				-94.586498, -94.586841, -94.586895 };
		
		LatLng pnts_first = new LatLng(c[0], d[0]);
		LatLng pnts_last = new LatLng(39.036681, -94.586895);
		PolylineOptions lineOptions = new PolylineOptions().width(15)
				.color(Color.BLUE).geodesic(true);

		for (i = 0; i < c.length; i++) {

			pnts = new LatLng(c[i], d[i]);
			lineOptions.add(pnts);

		}
		SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
				.findFragmentById(R.id.map);
		Map = mapFragment.getMap();

		Marker marker = Map.addMarker(new MarkerOptions()
				.position(pnts_first)
				.title("Initial")
				.icon(BitmapDescriptorFactory
						.fromResource(R.drawable.marker2)));

		Marker marker1 = Map.addMarker(new MarkerOptions()
				.position(pnts_last)
				.title("Final")
				.icon(BitmapDescriptorFactory
						.fromResource(R.drawable.marker3)));
		// lineOptions.add(pnts1);
		// lineOptions.add(pnts10);

		Map.addPolyline(lineOptions);
		CameraPosition cameraP = new CameraPosition.Builder().target(pnts)
				.zoom(16).bearing(90) // Sets the orientation of the camera
										// to
										// east
				.tilt(30) // Sets the tilt of the camera to 30 degrees
				.build();
		Map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraP));
		Map.setMapType(GoogleMap.MAP_TYPE_NORMAL);


	}
	
	public void method3()
	{int i=0;
	LatLng pnts = null;
	ArrayList<Double> lat = new ArrayList<Double>();
	lat = TestGesture.latge;
	
	ArrayList<Double> longe = new ArrayList<Double>();
	longe = TestGesture.longge;
	HashSet<Double> noDupe = new HashSet<Double>();
	noDupe.addAll(lat);
	lat.clear();
	lat.addAll(noDupe);
	HashSet<Double> noDupe1 = new HashSet<Double>();
	noDupe1.addAll(longe);
	longe.clear();
	longe.addAll(noDupe1);
		double e[] = { 39.037646, 39.037346, 39.037062, 39.036846, 39.036596,
				39.036604, 39.036596, 39.036604 };
		double f[] = { -94.584829, -94.584851, -94.584883, -94.584883,
				-94.585205, -94.585473, -94.585473, -94.585967 };
		int s=lat.size() - 1;
		int r=longe.size() - 1;
		LatLng pnts_first = new LatLng(lat.get(0), longe.get(0));
		LatLng pnts_last = new LatLng(lat.get(s),longe.get(r));
		PolylineOptions lineOptions = new PolylineOptions().width(15)
				.color(Color.BLUE).geodesic(true);

		for (i = 0; i <= s; i++) {

			pnts = new LatLng(lat.get(i),longe.get(i));
			lineOptions.add(pnts);

		}
		SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
				.findFragmentById(R.id.map);
		Map = mapFragment.getMap();

		Marker marker = Map.addMarker(new MarkerOptions()
				.position(pnts_first)
				.title("Initial")
				.icon(BitmapDescriptorFactory
						.fromResource(R.drawable.marker2)));

		Marker marker1 = Map.addMarker(new MarkerOptions()
				.position(pnts_last)
				.title("Final")
				.icon(BitmapDescriptorFactory
						.fromResource(R.drawable.marker3)));
		// lineOptions.add(pnts1);
		// lineOptions.add(pnts10);

		Map.addPolyline(lineOptions);
		CameraPosition cameraP = new CameraPosition.Builder().target(pnts)
				.zoom(16).bearing(90) // Sets the orientation of the camera
										// to
										// east
				.tilt(30) // Sets the tilt of the camera to 30 degrees
				.build();
		Map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraP));
		Map.setMapType(GoogleMap.MAP_TYPE_NORMAL);


	}
}
