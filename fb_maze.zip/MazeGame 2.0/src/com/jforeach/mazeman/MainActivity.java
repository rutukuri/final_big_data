package com.jforeach.mazeman;

import java.util.ArrayList;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

public class MainActivity extends Activity implements OnItemSelectedListener {
	List<Integer> graph = new ArrayList<Integer>();
	private String[] time = new String[] { "10AM", "12PM", "3PM", "6PM",
			"10PM", "1AM", };
	Spinner grpah_spinner;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		grpah_spinner = (Spinner) findViewById(R.id.spin_graph);
		ArrayList<String> graph_date = new ArrayList<String>();
		graph_date.add("Select Date");
		graph_date.add("07/28/2014");
		graph_date.add("07/29/2014");
		graph_date.add("07/30/2014");
		graph_date.add("07/31/2014");
		ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
				this, android.R.layout.simple_spinner_item, graph_date); // selected
																			// item
																			// will
																			// look
																			// like
																			// a
																			// spinner
																			// set
																			// from
																			// XML
		spinnerArrayAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		grpah_spinner.setAdapter(spinnerArrayAdapter);

		grpah_spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parentView,
					View selectedItemView, int position, long id) {
				if (position == 1) {

					openChart1();
				} else if (position == 2) {
					openChart2();
				} else if (position == 3) {
					openChart3();
				} else if (position == 4) {
					openChart();
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub

			}

		});
	}

	private void openChart() {

		/*
		 * int[] x = { 1,2,3,4,5}; x=new ArrayList<Integer>() int[] left = {
		 * 12,1,14,6,20}; int[] right = {20, 5, 9, 21, 7}; int[] top =
		 * {5,19,21,5,4};
		 */
		// public static ArrayList<Integer> x[] = new ArrayList<Integer>();

		ArrayList<Integer> x = new ArrayList<Integer>();
		x.add(1);
		x.add(2);
		x.add(3);
		x.add(4);
		x.add(5);
		// x.add(6);
		// x.add(7);
		// x.add(8);
		// x.add(9);

		ArrayList<Integer> left = new ArrayList<Integer>();
		left = TestGesture.leftge;
		ArrayList<Integer> right = new ArrayList<Integer>();
		right = TestGesture.rightge;
		ArrayList<Integer> top = new ArrayList<Integer>();
		top = TestGesture.topge;
		ArrayList<Integer> bottom = new ArrayList<Integer>();
		bottom = TestGesture.bottomge;
		// left=TestGesture.leftge;
		// Creating an XYSeries for Income
		XYSeries leftSeries = new XYSeries("Left Gesture");
		// Creating an XYSeries for Income
		XYSeries rightSeries = new XYSeries("Right Gesture");

		// Creating an XYSeries for fun
		XYSeries topSeries = new XYSeries("Top Gesture");
		XYSeries bottomSeries = new XYSeries("Bottom Gesture");
		// Adding data to Income and Expense Series
		for (int i = 0; i < x.size()/* x.length */; i++) {

			leftSeries.add(x.get(i), left.get(i));
			// leftSeries.add(x, left);
			rightSeries.add(x.get(i), right.get(i));
			topSeries.add(x.get(i), top.get(i));
			bottomSeries.add(x.get(i), bottom.get(i));
		}

		// Creating a dataset to hold each series
		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		// Adding Income Series to the dataset
		dataset.addSeries(leftSeries);
		// Adding Expense Series to dataset
		dataset.addSeries(rightSeries);
		dataset.addSeries(topSeries);
		dataset.addSeries(bottomSeries);

		// Creating XYSeriesRenderer to customize incomeSeries
		XYSeriesRenderer leftRenderer = new XYSeriesRenderer();
		leftRenderer.setColor(Color.WHITE);
		leftRenderer.setPointStyle(PointStyle.CIRCLE);
		leftRenderer.setFillPoints(true);
		leftRenderer.setLineWidth(2);
		leftRenderer.setDisplayChartValues(true);

		// Creating XYSeriesRenderer to customize expenseSeries
		XYSeriesRenderer rightRenderer = new XYSeriesRenderer();
		rightRenderer.setColor(Color.GREEN);
		rightRenderer.setPointStyle(PointStyle.CIRCLE);
		rightRenderer.setFillPoints(true);
		rightRenderer.setLineWidth(3);
		rightRenderer.setDisplayChartValues(true);

		// Creating XYSeriesRenderer to customize incomeSeries
		XYSeriesRenderer topRenderer = new XYSeriesRenderer();
		topRenderer.setColor(Color.RED);
		topRenderer.setPointStyle(PointStyle.CIRCLE);
		topRenderer.setFillPoints(true);
		topRenderer.setLineWidth(4);
		topRenderer.setDisplayChartValues(true);
		// Creating XYSeriesRenderer to customize incomeSeries
				XYSeriesRenderer bottomRenderer = new XYSeriesRenderer();
				bottomRenderer.setColor(Color.YELLOW);
				bottomRenderer.setPointStyle(PointStyle.CIRCLE);
				bottomRenderer.setFillPoints(true);
				bottomRenderer.setLineWidth(4);
				bottomRenderer.setDisplayChartValues(true);

		// Creating a XYMultipleSeriesRenderer to customize the whole chart
		XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
		multiRenderer.setXLabels(0);
		multiRenderer.setChartTitle("Comparison between different gestures");
		multiRenderer.setXTitle("Time");
		multiRenderer.setYTitle("Count");
		multiRenderer.setZoomButtonsVisible(true);
		for (int i = 0; i < x.size(); i++) {
			multiRenderer.addXTextLabel(i + 1, time[i]);
		}

		// Adding incomeRenderer and expenseRenderer to multipleRenderer
		// Note: The order of adding dataseries to dataset and renderers to
		// multipleRenderer
		// should be same
		multiRenderer.addSeriesRenderer(leftRenderer);
		multiRenderer.addSeriesRenderer(rightRenderer);
		multiRenderer.addSeriesRenderer(topRenderer);
		multiRenderer.addSeriesRenderer(bottomRenderer);
		// Creating an intent to plot line chart using dataset and
		// multipleRenderer
		Intent intent = ChartFactory.getLineChartIntent(getBaseContext(),
				dataset, multiRenderer);

		// Start Activity
		startActivity(intent);

	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub

	}

	private void openChart1() {

		
		 int[] x = { 1,2,3,4,5}; 
		 int[] left = {
		  12,1,14,6,20}; 
		 int[] right = {20, 5, 9, 21, 7};
		 int[] top =
		  {5,19,21,5,4};
		 int[] bottom =
			  {7,18,24,7,6};
		 
		// public static ArrayList<Integer> x[] = new ArrayList<Integer>();
/*
		ArrayList<Integer> x = new ArrayList<Integer>();
		x.add(1);
		x.add(2);
		x.add(3);
		x.add(4);
		x.add(5);*/
		// x.add(6);
		// x.add(7);
		// x.add(8);
		// x.add(9);

		//ArrayList<Integer> left = new ArrayList<Integer>();
		//left = TestGesture.leftge;
		//ArrayList<Integer> right = new ArrayList<Integer>();
		//right = TestGesture.rightge;
		//ArrayList<Integer> top = new ArrayList<Integer>();
		//top = TestGesture.topge;

		// left=TestGesture.leftge;
		// Creating an XYSeries for Income
		XYSeries leftSeries = new XYSeries("Left Gesture");
		// Creating an XYSeries for Income
		XYSeries rightSeries = new XYSeries("Right Gesture");

		// Creating an XYSeries for fun
		XYSeries topSeries = new XYSeries("Top Gesture");
		// Creating an XYSeries for fun
				XYSeries bottomSeries = new XYSeries("bottom Gesture");
		// Adding data to Income and Expense Series
		for (int i = 0; i < x.length; i++) {

			leftSeries.add(x[i], left[i]);
			// leftSeries.add(x, left);
			rightSeries.add(x[i], right[i]);
			topSeries.add(x[i], top[i]);
			bottomSeries.add(x[i], bottom[i]);
		}

		// Creating a dataset to hold each series
		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		// Adding Income Series to the dataset
		dataset.addSeries(leftSeries);
		// Adding Expense Series to dataset
		dataset.addSeries(rightSeries);
		dataset.addSeries(topSeries);
		dataset.addSeries(bottomSeries);

		// Creating XYSeriesRenderer to customize incomeSeries
		XYSeriesRenderer leftRenderer = new XYSeriesRenderer();
		leftRenderer.setColor(Color.WHITE);
		leftRenderer.setPointStyle(PointStyle.CIRCLE);
		leftRenderer.setFillPoints(true);
		leftRenderer.setLineWidth(2);
		leftRenderer.setDisplayChartValues(true);

		// Creating XYSeriesRenderer to customize expenseSeries
		XYSeriesRenderer rightRenderer = new XYSeriesRenderer();
		rightRenderer.setColor(Color.BLUE);
		rightRenderer.setPointStyle(PointStyle.CIRCLE);
		rightRenderer.setFillPoints(true);
		rightRenderer.setLineWidth(3);
		rightRenderer.setDisplayChartValues(true);

		// Creating XYSeriesRenderer to customize incomeSeries
		XYSeriesRenderer topRenderer = new XYSeriesRenderer();
		topRenderer.setColor(Color.CYAN);
		topRenderer.setPointStyle(PointStyle.CIRCLE);
		topRenderer.setFillPoints(true);
		topRenderer.setLineWidth(4);
		topRenderer.setDisplayChartValues(true);
		// Creating XYSeriesRenderer to customize incomeSeries
				XYSeriesRenderer bottomRenderer = new XYSeriesRenderer();
				topRenderer.setColor(Color.YELLOW);
				topRenderer.setPointStyle(PointStyle.CIRCLE);
				topRenderer.setFillPoints(true);
				topRenderer.setLineWidth(4);
				topRenderer.setDisplayChartValues(true);

		// Creating a XYMultipleSeriesRenderer to customize the whole chart
		XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
		multiRenderer.setXLabels(0);
		multiRenderer.setChartTitle("Comparison between different gestures");
		multiRenderer.setXTitle("Time");
		multiRenderer.setYTitle("Count");
		multiRenderer.setZoomButtonsVisible(true);
		for (int i = 0; i < x.length; i++) {
			multiRenderer.addXTextLabel(i + 1, time[i]);
		}

		// Adding incomeRenderer and expenseRenderer to multipleRenderer
		// Note: The order of adding dataseries to dataset and renderers to
		// multipleRenderer
		// should be same
		multiRenderer.addSeriesRenderer(leftRenderer);
		multiRenderer.addSeriesRenderer(rightRenderer);
		multiRenderer.addSeriesRenderer(topRenderer);
		multiRenderer.addSeriesRenderer(bottomRenderer);

		// Creating an intent to plot line chart using dataset and
		// multipleRenderer
		Intent intent = ChartFactory.getLineChartIntent(getBaseContext(),
				dataset, multiRenderer);

		// Start Activity
		startActivity(intent);

	}

	private void openChart3() {

		 int[] x = { 1,2,3,4,5}; 
		 int[] left = {
		  2,6,8,1,7}; 
		 int[] right = {20,12,5,8,1};
		 int[] top =
		  {5,19,21,5,4};
		 int[] bottom =
			  {3,15,2,7,4};
		 
		// public static ArrayList<Integer> x[] = new ArrayList<Integer>();
/*
		ArrayList<Integer> x = new ArrayList<Integer>();
		x.add(1);
		x.add(2);
		x.add(3);
		x.add(4);
		x.add(5);*/
		// x.add(6);
		// x.add(7);
		// x.add(8);
		// x.add(9);

		//ArrayList<Integer> left = new ArrayList<Integer>();
		//left = TestGesture.leftge;
		//ArrayList<Integer> right = new ArrayList<Integer>();
		//right = TestGesture.rightge;
		//ArrayList<Integer> top = new ArrayList<Integer>();
		//top = TestGesture.topge;

		// left=TestGesture.leftge;
		// Creating an XYSeries for Income
		XYSeries leftSeries = new XYSeries("Left Gesture");
		// Creating an XYSeries for Income
		XYSeries rightSeries = new XYSeries("Right Gesture");

		// Creating an XYSeries for fun
		XYSeries topSeries = new XYSeries("Top Gesture");
		// Creating an XYSeries for fun
				XYSeries bottomSeries = new XYSeries("bottom Gesture");
		// Adding data to Income and Expense Series
		for (int i = 0; i < x.length; i++) {

			leftSeries.add(x[i], left[i]);
			// leftSeries.add(x, left);
			rightSeries.add(x[i], right[i]);
			topSeries.add(x[i], top[i]);
			bottomSeries.add(x[i], bottom[i]);
		}

		// Creating a dataset to hold each series
		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		// Adding Income Series to the dataset
		dataset.addSeries(leftSeries);
		// Adding Expense Series to dataset
		dataset.addSeries(rightSeries);
		dataset.addSeries(topSeries);
		dataset.addSeries(bottomSeries);
		// Creating XYSeriesRenderer to customize incomeSeries
		XYSeriesRenderer leftRenderer = new XYSeriesRenderer();
		leftRenderer.setColor(Color.GRAY);
		leftRenderer.setPointStyle(PointStyle.CIRCLE);
		leftRenderer.setFillPoints(true);
		leftRenderer.setLineWidth(2);
		leftRenderer.setDisplayChartValues(true);

		// Creating XYSeriesRenderer to customize expenseSeries
		XYSeriesRenderer rightRenderer = new XYSeriesRenderer();
		rightRenderer.setColor(Color.BLUE);
		rightRenderer.setPointStyle(PointStyle.CIRCLE);
		rightRenderer.setFillPoints(true);
		rightRenderer.setLineWidth(3);
		rightRenderer.setDisplayChartValues(true);

		// Creating XYSeriesRenderer to customize incomeSeries
		XYSeriesRenderer topRenderer = new XYSeriesRenderer();
		topRenderer.setColor(Color.GREEN);
		topRenderer.setPointStyle(PointStyle.CIRCLE);
		topRenderer.setFillPoints(true);
		topRenderer.setLineWidth(4);
		topRenderer.setDisplayChartValues(true);
		
		// Creating XYSeriesRenderer to customize incomeSeries
				XYSeriesRenderer bottomRenderer = new XYSeriesRenderer();
				topRenderer.setColor(Color.YELLOW);
				topRenderer.setPointStyle(PointStyle.CIRCLE);
				topRenderer.setFillPoints(true);
				topRenderer.setLineWidth(4);
				topRenderer.setDisplayChartValues(true);

		// Creating a XYMultipleSeriesRenderer to customize the whole chart
		XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
		multiRenderer.setXLabels(0);
		multiRenderer.setChartTitle("Comparison between different gestures");
		multiRenderer.setXTitle("Time");
		multiRenderer.setYTitle("Count");
		multiRenderer.setZoomButtonsVisible(true);
		for (int i = 0; i < x.length; i++) {
			multiRenderer.addXTextLabel(i + 1, time[i]);
		}

		// Adding incomeRenderer and expenseRenderer to multipleRenderer
		// Note: The order of adding dataseries to dataset and renderers to
		// multipleRenderer
		// should be same
		multiRenderer.addSeriesRenderer(leftRenderer);
		multiRenderer.addSeriesRenderer(rightRenderer);
		multiRenderer.addSeriesRenderer(topRenderer);
		multiRenderer.addSeriesRenderer(bottomRenderer);

		// Creating an intent to plot line chart using dataset and
		// multipleRenderer
		Intent intent = ChartFactory.getLineChartIntent(getBaseContext(),
				dataset, multiRenderer);

		// Start Activity
		startActivity(intent);

	}

	private void openChart2() {

		 int[] x = { 1,2,3,4,5}; 
		 int[] left = {
		  12,1,12,1,5}; 
		 int[] right = {20, 5,12,4,7};
		 int[] top =
		  {5,18,15,21,1};
		 int[] bottom =
			  {7,15,12,2,6};
		// public static ArrayList<Integer> x[] = new ArrayList<Integer>();
/*
		ArrayList<Integer> x = new ArrayList<Integer>();
		x.add(1);
		x.add(2);
		x.add(3);
		x.add(4);
		x.add(5);*/
		// x.add(6);
		// x.add(7);
		// x.add(8);
		// x.add(9);

		//ArrayList<Integer> left = new ArrayList<Integer>();
		//left = TestGesture.leftge;
		//ArrayList<Integer> right = new ArrayList<Integer>();
		//right = TestGesture.rightge;
		//ArrayList<Integer> top = new ArrayList<Integer>();
		//top = TestGesture.topge;

		// left=TestGesture.leftge;
		// Creating an XYSeries for Income
		XYSeries leftSeries = new XYSeries("Left Gesture");
		// Creating an XYSeries for Income
		XYSeries rightSeries = new XYSeries("Right Gesture");

		// Creating an XYSeries for fun
		XYSeries topSeries = new XYSeries("Top Gesture");
		// Creating an XYSeries for fun
		XYSeries bottomSeries = new XYSeries("bottom Gesture");
		// Adding data to Income and Expense Series
		for (int i = 0; i < x.length; i++) {

			leftSeries.add(x[i], left[i]);
			// leftSeries.add(x, left);
			rightSeries.add(x[i], right[i]);
			topSeries.add(x[i], top[i]);
			bottomSeries.add(x[i], bottom[i]);
		}

		// Creating a dataset to hold each series
		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		// Adding Income Series to the dataset
		dataset.addSeries(leftSeries);
		// Adding Expense Series to dataset
		dataset.addSeries(rightSeries);
		dataset.addSeries(topSeries);
		dataset.addSeries(bottomSeries);

		// Creating XYSeriesRenderer to customize incomeSeries
		XYSeriesRenderer leftRenderer = new XYSeriesRenderer();
		leftRenderer.setColor(Color.GRAY);
		leftRenderer.setPointStyle(PointStyle.CIRCLE);
		leftRenderer.setFillPoints(true);
		leftRenderer.setLineWidth(2);
		leftRenderer.setDisplayChartValues(true);

		// Creating XYSeriesRenderer to customize expenseSeries
		XYSeriesRenderer rightRenderer = new XYSeriesRenderer();
		rightRenderer.setColor(Color.BLUE);
		rightRenderer.setPointStyle(PointStyle.CIRCLE);
		rightRenderer.setFillPoints(true);
		rightRenderer.setLineWidth(3);
		rightRenderer.setDisplayChartValues(true);

		// Creating XYSeriesRenderer to customize incomeSeries
				XYSeriesRenderer topRenderer = new XYSeriesRenderer();
				topRenderer.setColor(Color.YELLOW);
				topRenderer.setPointStyle(PointStyle.CIRCLE);
				topRenderer.setFillPoints(true);
				topRenderer.setLineWidth(4);
				topRenderer.setDisplayChartValues(true);
				// Creating XYSeriesRenderer to customize incomeSeries
				XYSeriesRenderer bottomRenderer = new XYSeriesRenderer();
				topRenderer.setColor(Color.CYAN);
				topRenderer.setPointStyle(PointStyle.CIRCLE);
				topRenderer.setFillPoints(true);
				topRenderer.setLineWidth(4);
				topRenderer.setDisplayChartValues(true);

		// Creating a XYMultipleSeriesRenderer to customize the whole chart
		XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
		multiRenderer.setXLabels(0);
		multiRenderer.setChartTitle("Comparison between different gestures");
		multiRenderer.setXTitle("Time");
		multiRenderer.setYTitle("Count");
		multiRenderer.setZoomButtonsVisible(true);
		for (int i = 0; i < x.length; i++) {
			multiRenderer.addXTextLabel(i + 1, time[i]);
		}

		// Adding incomeRenderer and expenseRenderer to multipleRenderer
		// Note: The order of adding dataseries to dataset and renderers to
		// multipleRenderer
		// should be same
		multiRenderer.addSeriesRenderer(leftRenderer);
		multiRenderer.addSeriesRenderer(rightRenderer);
		multiRenderer.addSeriesRenderer(topRenderer);
		multiRenderer.addSeriesRenderer(bottomRenderer);
		// Creating an intent to plot line chart using dataset and
		// multipleRenderer
		Intent intent = ChartFactory.getLineChartIntent(getBaseContext(),
				dataset, multiRenderer);

		// Start Activity
		startActivity(intent);

	}

}