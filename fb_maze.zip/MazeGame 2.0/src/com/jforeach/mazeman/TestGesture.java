package com.jforeach.mazeman;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.content.Intent;

import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Environment;
import android.text.format.DateFormat;
import android.util.Log;
import be.ac.ulg.montefiore.run.jahmm.Hmm;
import be.ac.ulg.montefiore.run.jahmm.ObservationVector;
import be.ac.ulg.montefiore.run.jahmm.OpdfMultiGaussianFactory;
import be.ac.ulg.montefiore.run.jahmm.io.ObservationSequencesReader;
import be.ac.ulg.montefiore.run.jahmm.io.ObservationVectorReader;
import be.ac.ulg.montefiore.run.jahmm.learn.BaumWelchLearner;
import be.ac.ulg.montefiore.run.jahmm.learn.KMeansLearner;

public class TestGesture {
	OpdfMultiGaussianFactory initFactoryPunch = null;
	OpdfMultiGaussianFactory initFactoryExe = null;
	Reader learnReaderPunch = null;
	Reader learnReaderExe = null;
	List<List<ObservationVector>> learnSequencesPunch = null;
	List<List<ObservationVector>> learnSequencesExe = null;
	KMeansLearner<ObservationVector> kMeansLearnerPunch = null;
	KMeansLearner<ObservationVector> kMeansLearnerExe = null;
	Hmm<ObservationVector> initHmmPunch = null;
	Hmm<ObservationVector> initHmmExe = null;
	Hmm<ObservationVector> learntHmmPunch = null;
	Hmm<ObservationVector> learntHmmScrolldown = null;
	Hmm<ObservationVector> learntHmmSend = null;
	Hmm<ObservationVector> learntHmmDown = null;
	Hmm<ObservationVector> learntHmmExe = null;
	String root = Environment.getExternalStorageDirectory().toString();
	File myDir = new File(root + "/Data");
	public static ArrayList<String> timeLine = new ArrayList<String>();
	public static int leftg = 0, rightg = 0, topg = 0, bottomg = 0;
	public static String dateg = "";
	public static ArrayList<Integer> leftge = new ArrayList<Integer>();
	public static ArrayList<Integer> rightge = new ArrayList<Integer>();
	public static ArrayList<Integer> topge = new ArrayList<Integer>();
	public static ArrayList<Integer> bottomge = new ArrayList<Integer>();
	public static ArrayList<Double> latge = new ArrayList<Double>();
	public static ArrayList<Double> longge = new ArrayList<Double>();
	String list_msg;

	public void train() {
		myDir.mkdirs();
		// Create HMM for punch gesture
		System.out.println("in train nmethosd");
		Boolean exception = false;
		int x = 10;
		while (!exception) {
			try {
				OpdfMultiGaussianFactory initFactoryPunch = new OpdfMultiGaussianFactory(
						3);

				Reader learnReaderPunch = new FileReader(new File(myDir,
						"goup.seq"));
				List<List<ObservationVector>> learnSequencesPunch = ObservationSequencesReader
						.readSequences(new ObservationVectorReader(),
								learnReaderPunch);
				learnReaderPunch.close();

				KMeansLearner<ObservationVector> kMeansLearnerPunch = new KMeansLearner<ObservationVector>(
						x, initFactoryPunch, learnSequencesPunch);
				// Create an estimation of the HMM (initHmm) using one iteration
				// of the
				// k-Means algorithm
				Hmm<ObservationVector> initHmmPunch = kMeansLearnerPunch
						.iterate();
				// Use BaumWelchLearner to create the HMM (learntHmm) from
				// initHmm

				BaumWelchLearner baumWelchLearnerPunch = new BaumWelchLearner();
				this.learntHmmPunch = baumWelchLearnerPunch.learn(initHmmPunch,
						learnSequencesPunch);
				exception = true;
				System.out.println(x);
			} catch (Exception e) {
				x--;
				// System.out.println(x);

			}

		}
		// Create HMM for scroll-down gesture
		Boolean exception1 = false;
		int x1 = 10;
		while (!exception1) {
			try {
				OpdfMultiGaussianFactory initFactoryScrolldown = new OpdfMultiGaussianFactory(
						3);

				Reader learnReaderScrolldown = new FileReader(new File(myDir,
						"goleft.seq"));
				List<List<ObservationVector>> learnSequencesScrolldown = ObservationSequencesReader
						.readSequences(new ObservationVectorReader(),
								learnReaderScrolldown);
				learnReaderScrolldown.close();

				KMeansLearner<ObservationVector> kMeansLearnerScrolldown = new KMeansLearner<ObservationVector>(
						x1, initFactoryScrolldown, learnSequencesScrolldown);
				// Create an estimation of the HMM (initHmm) using one iteration
				// of the
				// k-Means algorithm
				Hmm<ObservationVector> initHmmScrolldown = kMeansLearnerScrolldown
						.iterate();

				// Use BaumWelchLearner to create the HMM (learntHmm) from
				// initHmm
				BaumWelchLearner baumWelchLearnerScrolldown = new BaumWelchLearner();
				this.learntHmmScrolldown = baumWelchLearnerScrolldown.learn(
						initHmmScrolldown, learnSequencesScrolldown);
				exception1 = true;
				// System.out.println("here1");
				System.out.println(x1);
			} catch (Exception e) {
				x1--;
				// System.out.println(x1);

			}
		}

		// Create HMM for send gesture
		Boolean exception2 = false;
		int x2 = 10;
		while (!exception2) {
			try {
				OpdfMultiGaussianFactory initFactorySend = new OpdfMultiGaussianFactory(
						3);

				Reader learnReaderSend = new FileReader(new File(myDir,
						"goright.seq"));
				List<List<ObservationVector>> learnSequencesSend = ObservationSequencesReader
						.readSequences(new ObservationVectorReader(),
								learnReaderSend);
				learnReaderSend.close();

				KMeansLearner<ObservationVector> kMeansLearnerSend = new KMeansLearner<ObservationVector>(
						x2, initFactorySend, learnSequencesSend);
				// Create an estimation of the HMM (initHmm) using one iteration
				// of the
				// k-Means algorithm
				Hmm<ObservationVector> initHmmSend = kMeansLearnerSend
						.iterate();

				// Use BaumWelchLearner to create the HMM (learntHmm) from
				// initHmm
				BaumWelchLearner baumWelchLearnerSend = new BaumWelchLearner();
				this.learntHmmSend = baumWelchLearnerSend.learn(initHmmSend,
						learnSequencesSend);
				exception2 = true;
				System.out.println(x2);
			} catch (Exception e) {
				x2--;
				// System.out.println(x2);

			}
		}

		// Create HMM for down gesture
		Boolean exception3 = false;
		int x3 = 10;
		while (!exception3) {
			try {
				OpdfMultiGaussianFactory initFactoryDown = new OpdfMultiGaussianFactory(
						3);

				Reader learnReaderDown = new FileReader(new File(myDir,
						"gopunch.seq"));
				List<List<ObservationVector>> learnSequencesDown = ObservationSequencesReader
						.readSequences(new ObservationVectorReader(),
								learnReaderDown);
				learnReaderDown.close();

				KMeansLearner<ObservationVector> kMeansLearnerSend = new KMeansLearner<ObservationVector>(
						x3, initFactoryDown, learnSequencesDown);
				// Create an estimation of the HMM (initHmm) using one iteration
				// of the
				// k-Means algorithm
				Hmm<ObservationVector> initHmmDown = kMeansLearnerSend
						.iterate();

				// Use BaumWelchLearner to create the HMM (learntHmm) from
				// initHmm
				BaumWelchLearner baumWelchLearnerDown = new BaumWelchLearner();
				this.learntHmmDown = baumWelchLearnerDown.learn(initHmmDown,
						learnSequencesDown);
				exception3 = true;
				System.out.println(x3);
			} catch (Exception e) {
				x3--;
				// System.out.println(x2);

			}
		}
/*
		// Create HMM for down gesture
				Boolean exception4 = false;
				int x4 = 10;
				while (!exception4) {
					try {
						OpdfMultiGaussianFactory initFactoryExe = new OpdfMultiGaussianFactory(
								3);

						Reader learnReaderExe = new FileReader(new File(myDir,
								"goexercise.seq"));
						List<List<ObservationVector>> learnSequencesExe = ObservationSequencesReader
								.readSequences(new ObservationVectorReader(),
										learnReaderExe);
						learnReaderExe.close();

						KMeansLearner<ObservationVector> kMeansLearnerExe = new KMeansLearner<ObservationVector>(
								x4, initFactoryExe, learnSequencesExe);
						// Create an estimation of the HMM (initHmm) using one iteration
						// of the
						// k-Means algorithm
						Hmm<ObservationVector> initHmmExe = kMeansLearnerExe
								.iterate();

						// Use BaumWelchLearner to create the HMM (learntHmm) from
						// initHmm
						BaumWelchLearner baumWelchLearnerExe = new BaumWelchLearner();
						this.learntHmmExe = baumWelchLearnerExe.learn(initHmmExe,
								learnSequencesExe);
						exception4 = true;
						System.out.println(x4);
					} catch (Exception e) {
						x4--;
						// System.out.println(x4);

					}
				}

*/
	}

	/*
	 * public static void insertTable(int left1, int right1, int top1, String
	 * date1) throws IOException { System.out.println("in insert table");
	 * Configuration config = HBaseConfiguration.create(); config.clear();
	 * config.set("hbase.zookeeper.quorum", "134.193.136.147");
	 * config.set("hbase.zookeeper.property.clientPort", "2181");
	 * config.set("hbase.master", "134.193.136.147:60010");
	 * 
	 * String left = "", right = "", Date = "", top = "", y = "", z = "";
	 * 
	 * HTable table = new HTable(config, "gestureTable2");
	 * 
	 * // Put p = new Put(Bytes.toBytes("row1"));
	 * 
	 * int count = 1; int timestamp = 10000; int a = 0;
	 * 
	 * //BufferedReader br = null;
	 * 
	 * try {
	 * 
	 * //String sCurrentLine;
	 * 
	 * //br = new BufferedReader(new FileReader("D://gesture.txt"));
	 * 
	 * //while ((sCurrentLine = br.readLine()) != null) {
	 * 
	 * // Put p = new Put(Bytes.toBytes("row1"), timestamp);
	 * 
	 * //if (sCurrentLine.equals("")) { // continue; //}
	 * 
	 * //String[] array = sCurrentLine.split("\t"); left =
	 * Integer.toString(left1);
	 * 
	 * right = Integer.toString(right1); top = Integer.toString(top1); Date =
	 * date1; //if (Date.equals(array[3])) { // System.out.println("im in else"
	 * + Date + array[3] + a); // Date = array[3];
	 * 
	 * Put p = new Put(Bytes.toBytes("row" + date1), timestamp);
	 * 
	 * p.add(Bytes.toBytes("Date"), Bytes.toBytes("col" + (count)),
	 * Bytes.toBytes(Date));
	 * 
	 * p.add(Bytes.toBytes("left"), Bytes.toBytes("col" + (count + 1)),
	 * Bytes.toBytes(left));
	 * 
	 * p.add(Bytes.toBytes("right"), Bytes.toBytes("col" + (count + 2)),
	 * Bytes.toBytes(right)); p.add(Bytes.toBytes("top"), Bytes.toBytes("col" +
	 * (count + 3)), Bytes.toBytes(top));
	 * 
	 * // p.add(Bytes.toBytes("gyroscope"), //
	 * Bytes.toBytes("col"+(count+4)),Bytes.toBytes(x1+","+y1+","+z1));
	 * 
	 * // p.add(Bytes.toBytes("y"), //
	 * Bytes.toBytes("col"+(count+4)),Bytes.toBytes(y));
	 * 
	 * // p.add(Bytes.toBytes("z"), //
	 * Bytes.toBytes("col"+(count+5)),Bytes.toBytes(z));
	 * 
	 * table.put(p);
	 * 
	 * /*} else { System.out.println("im in if" + Date + array[3] + a); a++;
	 * Date = array[3];
	 * 
	 * Put p = new Put(Bytes.toBytes("row" + a), timestamp);
	 * p.add(Bytes.toBytes("Date"), Bytes.toBytes("col" + (count)),
	 * Bytes.toBytes(Date));
	 * 
	 * p.add(Bytes.toBytes("left"), Bytes.toBytes("col" + (count + 1)),
	 * Bytes.toBytes(left));
	 * 
	 * p.add(Bytes.toBytes("right"), Bytes.toBytes("col" + (count + 2)),
	 * Bytes.toBytes(right)); p.add(Bytes.toBytes("top"), Bytes.toBytes("col" +
	 * (count + 3)), Bytes.toBytes(top));
	 * 
	 * // p.add(Bytes.toBytes("gyroscope"), //
	 * Bytes.toBytes("col"+(count+4)),Bytes.toBytes(x1+","+y1+","+z1));
	 * 
	 * // p.add(Bytes.toBytes("y"), //
	 * Bytes.toBytes("col"+(count+4)),Bytes.toBytes(y));
	 * 
	 * // p.add(Bytes.toBytes("z"), //
	 * Bytes.toBytes("col"+(count+5)),Bytes.toBytes(z));
	 * 
	 * table.put(p);
	 * 
	 * }
	 * 
	 * // p.add(Bytes.toBytes("GeoLocation"), //
	 * Bytes.toBytes("col"+count),Bytes.toBytes(latitude+","+longitude));
	 * 
	 * // p.add(Bytes.toBytes("longitude"), //
	 * Bytes.toBytes("col"+(count+1)),Bytes.toBytes(longitude));
	 * 
	 * // p.add(Bytes.toBytes("Date"), Bytes.toBytes("col" + (count)), //
	 * Bytes.toBytes(Date));
	 * 
	 * // p.add(Bytes.toBytes("left"), // Bytes.toBytes("col" + (count + 1)),
	 * Bytes.toBytes(left));
	 * 
	 * // p.add(Bytes.toBytes("right"), // Bytes.toBytes("col" + (count + 2)),
	 * // Bytes.toBytes(right)); // p.add(Bytes.toBytes("top"),
	 * Bytes.toBytes("col" + (count + // 3)), // Bytes.toBytes(top));
	 * 
	 * // p.add(Bytes.toBytes("gyroscope"), //
	 * Bytes.toBytes("col"+(count+4)),Bytes.toBytes(x1+","+y1+","+z1));
	 * 
	 * // p.add(Bytes.toBytes("y"), //
	 * Bytes.toBytes("col"+(count+4)),Bytes.toBytes(y));
	 * 
	 * // p.add(Bytes.toBytes("z"), //
	 * Bytes.toBytes("col"+(count+5)),Bytes.toBytes(z));
	 * 
	 * // table.put(p);
	 * 
	 * count = count + 1; timestamp = timestamp + 1;
	 * 
	 * }
	 */
	/*
	 * } catch (IOException e) { e.printStackTrace(); } }
	 */
	public String test(File seqfilename) throws Exception {
		int left = 0, right = 0, top = 0, bottom = 0;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		dateg = dateFormat.format(date);
		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:MM:ss");
		Date date1 = new Date();
		String data = null;
		Intent intent = new Intent();
		Reader testReader = new FileReader(seqfilename);
		List<List<ObservationVector>> testSequences = ObservationSequencesReader
				.readSequences(new ObservationVectorReader(), testReader);
		testReader.close();

		short gesture; // punch = 1, scrolldown = 2, send = 3
		double punchProbability, scrolldownProbability, sendProbability, downProbability, exeProbability;
		for (int i = 0; i < testSequences.size(); i++) {

			punchProbability = this.learntHmmPunch.probability(testSequences
					.get(i));
			// System.out.println(this.learntHmmPunch.probability(testSequences.get(i)));
			gesture = 1;
			// System.out.println(this.learntHmmScrolldown);
			scrolldownProbability = this.learntHmmScrolldown
					.probability(testSequences.get(i));

			if (scrolldownProbability > punchProbability) {
				gesture = 2;
			}
			sendProbability = this.learntHmmSend.probability(testSequences
					.get(i));
			// System.out.println(punchProbability +","+scrolldownProbability
			// +","+sendProbability);
			if ((gesture == 1 && sendProbability > punchProbability)
					|| (gesture == 2 && sendProbability > scrolldownProbability)) {
				gesture = 3;
			}

			downProbability = this.learntHmmDown.probability(testSequences
					.get(i));
			// System.out.println(punchProbability +","+scrolldownProbability
			// +","+sendProbability);
			if ((gesture == 1 && downProbability > punchProbability)
					|| (gesture == 2 && downProbability > scrolldownProbability)
					|| (gesture == 3 && downProbability > sendProbability)) {
				gesture = 4;
			}/*
			exeProbability = this.learntHmmExe.probability(testSequences
					.get(i));
			// System.out.println(punchProbability +","+scrolldownProbability
			// +","+sendProbability);
			if ((gesture == 1 && exeProbability > punchProbability)
					|| (gesture == 2 && exeProbability > scrolldownProbability)
					|| (gesture == 3 && exeProbability > sendProbability)
					|| (gesture == 4 && exeProbability > downProbability)) {
				gesture = 5;
			}
*/
			Log.i("probabilities", punchProbability + "   " + sendProbability
					+ "   " + scrolldownProbability + "   " + downProbability);
			if (gesture == 1) {
				top = 1;
				leftge.add(0);
				rightge.add(0);
				topge.add(1);
				bottomge.add(0);
				topg++;

				String string = "\n"
						+ String.valueOf(left)
						+ "\t"
						+ String.valueOf(right)
						+ "\t"
						+ String.valueOf(top)
						+ "\t"
						+ String.valueOf(bottom)
						+ "\t"
						+ String.valueOf(dateFormat.format(date) + "\t"
								+ ConnectionService.latitude + "\t"
								+ ConnectionService.longitude);
				// insertTable(0,0,1,String.valueOf(dateFormat.format(date)));
				SaveData(string);
				System.out.println("This is a top gesture");
				list_msg = " " + date1 + "\n" + "This is a top gesture";
				timeLine.add(list_msg);
				intent.putStringArrayListExtra("test",
						(ArrayList<String>) timeLine);
				return "bottom";
			} else if (gesture == 2) {
				right = 1;
				leftge.add(0);
				rightge.add(1);
				topge.add(0);
				bottomge.add(0);
				rightg++;
				String string = "\n"
						+ String.valueOf(left)
						+ "\t"
						+ String.valueOf(right)
						+ "\t"
						+ String.valueOf(top)
						+ "\t"
						+ String.valueOf(bottom)
						+ "\t"
						+ String.valueOf(dateFormat.format(date) + "\t"
								+ ConnectionService.latitude + "\t"
								+ ConnectionService.longitude);
				SaveData(string);
				// insertTable(0,1,0,String.valueOf(dateFormat.format(date)));
				System.out.println("This is a right gesture");
				list_msg = " " + date1 + "\n" + "This is a right gesture";
				timeLine.add(list_msg);
				intent.putStringArrayListExtra("test",
						(ArrayList<String>) timeLine);
				return "right";

			} else if (gesture == 3) {
				left = 1;
				leftge.add(1);
				rightge.add(0);
				topge.add(0);
				bottomge.add(0);
				leftg++;
				String string = "\n"
						+ String.valueOf(left)
						+ "\t"
						+ String.valueOf(right)
						+ "\t"
						+ String.valueOf(top)
						+ "\t"
						+ String.valueOf(bottom)
						+ "\t"
						+ String.valueOf(dateFormat.format(date) + "\t"
								+ ConnectionService.latitude + "\t"
								+ ConnectionService.longitude);
				SaveData(string);
				// insertTable(1,0,0,String.valueOf(dateFormat.format(date)));
				System.out.println("This is a left gesture");
				list_msg = " " + date1 + "\n" + "This is a left gesture";
				timeLine.add(list_msg);
				intent.putStringArrayListExtra("test",
						(ArrayList<String>) timeLine);
				return "left";
			} else if (gesture == 4) {
				bottom = 1;
				leftge.add(0);
				rightge.add(0);
				topge.add(0);
				bottomge.add(1);
				latge.add(ConnectionService.latitude);
				longge.add(ConnectionService.longitude);
				bottomg++;

				String string = "\n"
						+ String.valueOf(left)
						+ "\t"
						+ String.valueOf(right)
						+ "\t"
						+ String.valueOf(top)
						+ "\t"
						+ String.valueOf(bottom)
						+ "\t"
						+ String.valueOf(dateFormat.format(date) + "\t"
								+ ConnectionService.latitude + "\t"
								+ ConnectionService.longitude);
				SaveData(string);
				// insertTable(1,0,0,String.valueOf(dateFormat.format(date)));
				System.out.println("This is a bottom gesture");
				list_msg = " " + date1 + "\n" + "This is a bottom gesture";
				timeLine.add(list_msg);
				intent.putStringArrayListExtra("test",
						(ArrayList<String>) timeLine);
				return "up";
			} /*else if (gesture == 5) {
				
				
				//latge.add(ConnectionService.latitude);
				//longge.add(ConnectionService.longitude);
								System.out.println("This is a exercisegesture");
				list_msg = " " + date1 + "\n" + "This is a exercise gesture";
				timeLine.add(list_msg);
				intent.putStringArrayListExtra("test",
						(ArrayList<String>) timeLine);
				return "exercise";
			}*/ else {
				return "others";
			}
		}
		return "others";
	}

	private void SaveData(String string) {
		// Log.i("string", string);
		File sdCard = Environment.getExternalStorageDirectory();
		File directory = new File(sdCard.getAbsolutePath() + "/Data");
		if (!directory.exists())
			directory.mkdirs();
		String fname = "try1.txt";
		File file = new File(directory, fname);

		try {
			if (!file.exists())
				file.createNewFile();
			FileOutputStream out = new FileOutputStream(file, true);
			out.write(string.getBytes());
			out.flush();
			out.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}