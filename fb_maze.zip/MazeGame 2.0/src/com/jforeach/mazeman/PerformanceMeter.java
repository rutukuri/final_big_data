package com.jforeach.mazeman;

import java.util.Locale;

import android.app.Activity;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class PerformanceMeter extends Activity implements
		TextToSpeech.OnInitListener {
	TextToSpeech tts;
	public static int f;

	// int f;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.performance);
		TextView t1 = (TextView) findViewById(R.id.txtLevel);

		tts = new TextToSpeech(this, this);
		ImageView img1 = new ImageView(this);
		img1 = (ImageView) findViewById(R.id.imgLevelr);
		int test = 40;
		int x = 0, y = 0, z = 0, h = 0;
		x = TestGesture.leftge.size();
		y = TestGesture.rightge.size();
		z = TestGesture.topge.size();
		h = x + y + z;

		if (h >= 0 && h <= 80) {
			Toast.makeText(getApplicationContext(), "Excellent Performance!",
					Toast.LENGTH_SHORT).show();
			f = 1;
			tts.speak("Excellent Performance!", TextToSpeech.QUEUE_FLUSH, null);
			img1.setImageResource(R.drawable.excellent);
			t1.setText("Excellent Performance!");
		} else if (h > 80 && h <= 160) {
			t1.setText("Great job. Keep rocking!");
			Toast.makeText(getApplicationContext(), "Great job. Keep rocking!",
					Toast.LENGTH_SHORT).show();
			f = 2;
			tts.speak("Great job. Keep rocking!", TextToSpeech.QUEUE_FLUSH,
					null);
			img1.setImageResource(R.drawable.good);
		} else if (h > 160 && h <= 220) {
			t1.setText("Average Performance.You can play better!");
			Toast.makeText(getApplicationContext(),
					"Average Performance.You can play better!",
					Toast.LENGTH_SHORT).show();
			f = 3;
			tts.speak("Average Performance.You can play better!",
					TextToSpeech.QUEUE_FLUSH, null);
			img1.setImageResource(R.drawable.concentrate);

		} else if (h > 220) {
			t1.setText("Worst Performance. Better luck next time!");
			tts.speak("Worst Performance. Better luck next time!",
					TextToSpeech.QUEUE_FLUSH, null);
			img1.setImageResource(R.drawable.tear);
			Toast.makeText(getApplicationContext(),
					"Worst Performance. Better luck next time!",
					Toast.LENGTH_SHORT).show();
			f = 4;
		}

	}

	@Override
	public void onInit(int status) {

		if (status == TextToSpeech.SUCCESS) {

			int result = tts.setLanguage(Locale.US);

			if (result == TextToSpeech.LANG_MISSING_DATA
					|| result == TextToSpeech.LANG_NOT_SUPPORTED) {
				Log.e("TTS", "This Language is not supported");
				System.out.println("in tts if");
			} else {
				if (f == 1) {
					System.out.println("in tts else");
					String tex = "We got a winner! Whoa. Congrats.";
					tts.speak(tex, TextToSpeech.QUEUE_FLUSH, null);
				} else if (f == 2) {
					System.out.println("in tts else");
					String tex = "Great job, keep rocking !";
					tts.speak(tex, TextToSpeech.QUEUE_FLUSH, null);
				} else if (f == 3) {
					System.out.println("in tts else");
					String tex = "Average Performance. You can play better!";
					tts.speak(tex, TextToSpeech.QUEUE_FLUSH, null);
				} else if (f == 4) {
					System.out.println("in tts else");
					String tex = "Worst Performance. Better luck next time!";
					tts.speak(tex, TextToSpeech.QUEUE_FLUSH, null);
				} else {
					System.out.println("in tts else");
					String tex = "No Comments.Play again!";
					tts.speak(tex, TextToSpeech.QUEUE_FLUSH, null);
				}

			}

		} else {
			Log.e("TTS", "Initilization Failed!");
		}

	}
}
